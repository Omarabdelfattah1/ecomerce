<?php $__env->startSection('page'); ?>
    <div class="container">
        <div class="row pt120">
            <div class="books-grid">

            <div class="row mb30">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="books-item">
                                <div class="books-item-thumb">
                                    <img src="<?php echo e(asset($product->image)); ?>" alt="book">
                                    <div class="new">New</div>
                                    <div class="sale">Sale</div>
                                    <div class="overlay overlay-books"></div>
                                </div>

                                <div class="books-item-info">
                                    <a href="product/<?php echo e($product->id); ?>">
                                        <h5 class="books-title"><?php echo e($product->name); ?></h5>
                                    </a>

                                    <div class="books-price">$<?php echo e($product->price); ?></div>
                                </div>
                            <form action="<?php echo e(route('cart.add')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                                <div class="quantity">
                                    <a href="#" class="quantity-minus quantity-minus-d">-</a>
                                    <input title="Qty" class="email input-text qty text" name="qty" type="text" value="1">
                                    <a href="#" class="quantity-plus quantity-plus-d">+</a>
                                </div>

                                <input type="hidden" name="pdt_id" value="<?php echo e($product->id); ?>">

                                <button class="btn btn-medium btn--primary" type="submit">
                                            <span class="text">Add to Cart</span>
                                            <i class="seoicon-commerce"></i>
                                            <span class="semicircle"></span>
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div><?php echo e($products->links()); ?>


            <div class="row pb120">

                <div class="col-lg-12"></div>

            </div>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.shop', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>